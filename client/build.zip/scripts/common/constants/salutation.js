define([], function () {
    'use strict';
    return {
		Mr: "Mr",
		Ms: "Ms",
		Mrs: "Mrs"
	};
});