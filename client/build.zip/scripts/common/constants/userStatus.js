define([], function () {
    'use strict';
    return {
		Active: "Active",
		Inactive: "Inactive",
		Suspended: "Suspended"
	};
});