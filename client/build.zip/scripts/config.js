//Config parameters which should be excluded from minification and are dynamic
define([],function(){
	'use strict';
	return {
		"wsBaseUri": "/api",
		"wsVersion": "v1.0",
		"version": "1.0",
		"mode": "test"
	};
});